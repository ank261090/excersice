import json
import os 
import boto3
s3 = boto3.client('s3')
ssm = boto3.client('ssm')
user = os.environ.get("USERNAME")

UserName = ssm.get_parameter(Name = user)
UserNameValue = UserName['Parameter']['Value']

def lambda_handler(event, context):
    print(UserNameValue)
    
    bucket_name = 'testbucket01tcs' 
    file_name = 'user_name.txt' 
    file_content =  user + "" + UserNameValue
    s3.put_object(Body=file_content, Bucket=bucket_name, Key=file_name) 
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
